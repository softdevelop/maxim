<div id="sidebar" class="widgets-area">
	<ul>
		<?php dynamic_sidebar( 'sidebar-1' ); ?>
	</ul>
</div>